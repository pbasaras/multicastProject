tc qdisc add dev ifb0 root netem loss $1%
