tc qdisc del dev $1 root
